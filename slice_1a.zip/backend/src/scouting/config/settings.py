"""Runtime configuration, read from the environment (and `.env` files) in one place.

The API key is a `SecretStr`, so it never shows up in `repr()`, logs or tracebacks.
It's optional at load time because offline commands (rebuilding scouting.db from
raw.db) don't need it; anything that calls the API uses `require_api_key()`.
"""

from __future__ import annotations

from pathlib import Path
from typing import Final

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

RAW_DB_FILENAME: Final = "raw.db"
SCOUTING_DB_FILENAME: Final = "scouting.db"


class MissingApiKeyError(RuntimeError):
    """Raised when a command needs PitchAPI but PITCHAPI_API_KEY isn't set."""


class Settings(BaseSettings):
    # Real environment variables win over .env files; of the files, the later one wins.
    # "../.env" is the repo root when running from backend/, which is where ours lives.
    model_config = SettingsConfigDict(
        env_file=("../.env", ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    pitchapi_api_key: SecretStr | None = Field(default=None, validation_alias="PITCHAPI_API_KEY")
    data_dir: Path = Field(default=Path("data"), validation_alias="SCOUTING_DATA_DIR")

    @property
    def raw_db_path(self) -> Path:
        return self.data_dir / RAW_DB_FILENAME

    @property
    def scouting_db_path(self) -> Path:
        return self.data_dir / SCOUTING_DB_FILENAME

    def require_api_key(self) -> str:
        if self.pitchapi_api_key is None or not self.pitchapi_api_key.get_secret_value():
            raise MissingApiKeyError(
                "PITCHAPI_API_KEY is not set. Put it in the repo-root .env "
                "(see .env.example) or export it."
            )
        return self.pitchapi_api_key.get_secret_value()
