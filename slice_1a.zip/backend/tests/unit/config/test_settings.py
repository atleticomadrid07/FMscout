"""Unit tests for Settings. `_env_file=None` keeps the real .env (and real key) out of tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from scouting.config.settings import MissingApiKeyError, Settings

FAKE_KEY = "pk_test_not_a_real_key"


@pytest.fixture(autouse=True)
def clean_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("PITCHAPI_API_KEY", raising=False)
    monkeypatch.delenv("SCOUTING_DATA_DIR", raising=False)


def load() -> Settings:
    return Settings(_env_file=None)  # type: ignore[call-arg]


def test_reads_api_key_from_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PITCHAPI_API_KEY", FAKE_KEY)
    assert load().require_api_key() == FAKE_KEY


def test_api_key_never_appears_in_repr(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PITCHAPI_API_KEY", FAKE_KEY)
    settings = load()
    assert FAKE_KEY not in repr(settings)
    assert FAKE_KEY not in str(settings.model_dump())


@pytest.mark.parametrize("value", [None, ""])
def test_require_api_key_missing_raises(monkeypatch: pytest.MonkeyPatch, value: str | None) -> None:
    if value is not None:
        monkeypatch.setenv("PITCHAPI_API_KEY", value)
    with pytest.raises(MissingApiKeyError):
        load().require_api_key()


def test_database_paths_default_to_data_dir() -> None:
    settings = load()
    assert settings.raw_db_path == Path("data") / "raw.db"
    assert settings.scouting_db_path == Path("data") / "scouting.db"


def test_data_dir_can_be_overridden(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SCOUTING_DATA_DIR", str(tmp_path))
    assert load().raw_db_path == tmp_path / "raw.db"


def test_reads_dotenv_file(tmp_path: Path) -> None:
    env_file = tmp_path / ".env"
    env_file.write_text(f"PITCHAPI_API_KEY={FAKE_KEY}\nUNRELATED=1\n")
    settings = Settings(_env_file=env_file)  # type: ignore[call-arg]
    assert settings.require_api_key() == FAKE_KEY
