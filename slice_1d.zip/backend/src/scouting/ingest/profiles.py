"""Player profiles (GET /v1/players/{id}), slice 1d.

The profile is the authority on a player's name, short name (used by search), country,
shirt number and listed position. Match data only fills fields that are still empty
(slice 1c). `profile_fetched_at` is the response's fetch time, not the clock, so a
rebuild from raw.db gives an identical database.
"""

from __future__ import annotations

import logging
from collections.abc import Iterable
from dataclasses import dataclass

from pydantic import ValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session

from scouting.adapters.pitchapi.cache import PROFILE, CachedFetcher, CacheMissError
from scouting.adapters.pitchapi.client import build_path
from scouting.adapters.pitchapi.raw_store import RawRecord
from scouting.adapters.pitchapi.schemas import PlayerProfile
from scouting.db.models import Player, PlayerSourceId, to_utc_naive
from scouting.ingest.match_detail import search_name
from scouting.ingest.match_list import SOURCE, SyncError

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class ProfileSummary:
    updated: int = 0
    unchanged: int = 0
    not_found: int = 0
    not_cached: int = 0  # offline runs only

    @property
    def total(self) -> int:
        return self.updated + self.unchanged + self.not_found + self.not_cached


def apply_profile(player: Player, record: RawRecord) -> bool:
    """Write a profile response onto a player; return whether anything changed."""
    try:
        profile = PlayerProfile.model_validate(record.data)
    except ValidationError as exc:
        raise SyncError(f"{record.path}: unexpected response shape\n{exc}") from exc
    values: dict[str, object] = {
        "name": profile.name,
        "search_name": search_name(profile.name),
        "short_name": profile.short_name,
        "country_code": profile.country_code,
        "shirt_number": None if profile.shirt_number is None else str(profile.shirt_number),
        "listed_slot_code": profile.position_id,
        "profile_fetched_at": to_utc_naive(record.fetched_at),
    }
    if profile.image_url is not None:
        values["image_url"] = profile.image_url
    changed = False
    for name, value in values.items():
        if getattr(player, name) != value:
            setattr(player, name, value)
            changed = True
    return changed


def sync_profiles(
    fetcher: CachedFetcher, session: Session, player_ids: Iterable[int] | None = None
) -> ProfileSummary:
    """Fetch (or read from cache) and apply profiles for the given players, or all players.
    Freshness is the fetcher's job (PROFILE: 90 days; 404s re-checked after 30)."""
    stmt = (
        select(Player, PlayerSourceId.external_id)
        .join(PlayerSourceId, PlayerSourceId.player_id == Player.id)
        .where(PlayerSourceId.source == SOURCE)
        .order_by(Player.id)
    )
    if player_ids is not None:
        stmt = stmt.where(Player.id.in_(list(player_ids)))
    summary = ProfileSummary()
    for player, external_id in session.execute(stmt).all():
        try:
            result = fetcher.get(build_path("players", external_id), policy=PROFILE)
        except CacheMissError:
            summary.not_cached += 1
            continue
        if not result.ok:
            logger.info("no profile for %s (%s)", external_id, result.error_code)
            summary.not_found += 1
            continue
        if apply_profile(player, result.record):
            summary.updated += 1
        else:
            summary.unchanged += 1
    session.flush()
    return summary
