"""Midfield depth for the 6/8 split (slice 2d-2, D-017).

The pure functions are tested on small hand-made rows with values worked out by hand; the
report on the three-match fixture season, with roles and names edited so it has central
midfielders and anchors.
"""

from __future__ import annotations

from typing import Any

import pytest
from sqlalchemy import Engine, select, update
from sqlalchemy.orm import Session

from scouting.db.models import Appearance, Player, PlayerSourceId
from scouting.ingest.season import find_season
from scouting.metrics import depth
from scouting.metrics.aggregate import aggregate_season
from scouting.metrics.depth import (
    AppearanceRow,
    Calibration,
    Cut,
    DepthReportError,
    MatchDepth,
    PlayerLine,
    SeasonDepth,
    best_cut,
    calibrate,
    histogram,
    label_for,
    match_depths,
    season_depths,
)

LEAGUE, SEASON = "l_FIXT01", "2025/2026"


def row(
    player: int, role: str | None, depth_: float | None, *, match: int = 1, team: int = 1,
    starter: bool = True, keeper: bool = False, minutes: int = 90,
) -> AppearanceRow:  # fmt: skip
    return AppearanceRow(match, team, player, starter, keeper, role, minutes, depth_)


# One team in one match: keeper excluded from the outfield reference; outfield mean is
# (0.30 + 0.34 + 0.45 + 0.44 + 0.55 + 0.65 + 0.70) / 7 = 0.49; centre-back mean 0.32.
SIDE = [
    row(1, "GK", 0.10, keeper=True),
    row(2, "CB", 0.30),
    row(3, "CB", 0.34),
    row(4, "FB", 0.45),
    row(5, "DM", 0.44),
    row(6, "CM", 0.55),
    row(7, "W", 0.65),
    row(8, "ST", 0.70),
    row(9, None, 0.20, starter=False),  # a sub: never part of the reference or the mids
]


# --- per match ------------------------------------------------------------------------------


def test_relative_to_the_outfield_players() -> None:
    result = {m.player_id: m for m in match_depths(SIDE, "outfield")}
    assert set(result) == {5, 6}  # the central midfielders only
    assert result[5].relative == pytest.approx(0.44 - 0.49)
    assert result[6].relative == pytest.approx(0.55 - 0.49)
    assert (result[5].deepest, result[6].deepest) == (True, False)


def test_relative_to_the_centre_backs() -> None:
    result = {m.player_id: m.relative for m in match_depths(SIDE, "centre_backs")}
    assert result == {5: pytest.approx(0.12), 6: pytest.approx(0.23)}


def test_no_reference_no_rows() -> None:
    no_centre_backs = [r for r in SIDE if r.role != "CB"]
    assert match_depths(no_centre_backs, "centre_backs") == []
    assert len(match_depths(no_centre_backs, "outfield")) == 2


def test_a_lone_midfielder_has_no_partner_to_compare() -> None:
    alone = [r for r in SIDE if r.player_id != 6]
    (only,) = match_depths(alone, "outfield")
    assert only.player_id == 5 and only.deepest is None


def test_midfielders_without_a_heatmap_are_left_out() -> None:
    no_heatmap = [row(6, "CM", None) if r.player_id == 6 else r for r in SIDE]
    result = match_depths(no_heatmap, "outfield")
    assert [m.player_id for m in result] == [5]
    assert result[0].deepest is None  # no second midfielder with a depth to compare


def test_teams_are_kept_apart() -> None:
    other = [
        row(101, "GK", 0.10, team=2, keeper=True),
        row(102, "CB", 0.30, team=2),
        row(103, "CB", 0.34, team=2),
        row(104, "FB", 0.45, team=2),
        row(105, "DM", 0.20, team=2),
        row(106, "CM", 0.55, team=2),
        row(107, "W", 0.65, team=2),
        row(108, "ST", 0.70, team=2),
    ]
    result = {m.player_id: m.relative for m in match_depths(SIDE + other, "outfield")}
    assert result[5] == pytest.approx(0.44 - 0.49)  # unchanged by the other team
    other_mean = (0.30 + 0.34 + 0.45 + 0.20 + 0.55 + 0.65 + 0.70) / 7
    assert result[105] == pytest.approx(0.20 - other_mean)


# --- per season -----------------------------------------------------------------------------


def test_season_is_minutes_weighted() -> None:
    starts = [
        MatchDepth(5, 1, 90, -0.10, True),
        MatchDepth(5, 2, 30, +0.10, False),
        MatchDepth(5, 3, 60, -0.04, None),  # alone in midfield: not comparable
    ]
    (season,) = season_depths(starts).values()
    assert season.relative == pytest.approx((-9 + 3 - 2.4) / 180)
    assert (season.starts, season.minutes, season.comparable, season.deepest) == (3, 180, 2, 1)
    assert season.deepest_share == pytest.approx(0.5)


@pytest.mark.parametrize(("starts", "enough"), [(4, False), (5, True), (6, True)])
def test_enough_starts(starts: int, enough: bool) -> None:
    assert SeasonDepth(1, starts, 90 * starts, -0.1, 0, 0).enough_starts is enough


# --- the cut --------------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("anchors", "cut", "wrong"),
    [
        # Clean split: the middle of the gap between the highest 6 and the lowest 8.
        ([("a", "DM", -0.06), ("b", "DM", -0.04), ("c", "CM", 0.02), ("d", "CM", 0.05)],
         -0.01, ()),
        # One 6 plays higher than an 8: the cut that gets the most anchors right.
        ([("a", "DM", -0.06), ("b", "DM", 0.03), ("c", "CM", 0.00), ("d", "CM", 0.05),
          ("e", "CM", 0.06)], -0.03, ("b",)),
        # Equal errors: the widest gap wins (0.02 to 0.08 over -0.04 to -0.02).
        ([("a", "DM", -0.04), ("b", "CM", -0.02), ("c", "DM", 0.02), ("d", "CM", 0.08)],
         0.05, ("b",)),
    ],
)  # fmt: skip
def test_best_cut(anchors: list[tuple[str, Any, float]], cut: float, wrong: tuple[str]) -> None:
    result = best_cut(anchors)
    assert result is not None
    assert result.value == pytest.approx(cut)
    assert result.wrong == wrong


def test_best_cut_needs_both_kinds() -> None:
    assert best_cut([("a", "DM", -0.1), ("b", "DM", 0.1)]) is None
    assert best_cut([]) is None


def test_best_cut_margin() -> None:
    result = best_cut([("a", "DM", -0.06), ("c", "CM", 0.02)])
    assert result == Cut(pytest.approx(-0.02), (), pytest.approx(0.04))  # type: ignore[arg-type]


def test_label_for() -> None:
    assert (label_for(-0.011, -0.01), label_for(-0.01, -0.01), label_for(0.2, -0.01)) == (
        "DM", "CM", "CM",
    )  # fmt: skip


def test_histogram() -> None:
    bins = histogram([-0.015, -0.005, 0.0, 0.004, 0.019], 0.01)
    assert [count for _, count in bins] == [1, 1, 2, 1]
    assert [start for start, _ in bins] == pytest.approx([-0.02, -0.01, 0.0, 0.01])
    assert histogram([], 0.01) == []


# --- what the report derives from a calibration ---------------------------------------------


def line(player: int, relative: float, starts: int = 10, deepest: int = 5) -> PlayerLine:
    return PlayerLine(
        player, f"P{player}", "T", SeasonDepth(player, starts, 900, relative, 10, deepest)
    )


def test_sizes_nearest_and_disagreements() -> None:
    group = [
        line(1, -0.08, deepest=9),
        line(2, -0.035, deepest=2),  # a 6 by depth, but rarely the deepest: listed
        line(3, -0.005),
        line(4, 0.01, deepest=8),  # an 8 by depth, but usually the deepest: listed
        line(5, 0.06, deepest=1),
        line(6, -0.2, starts=3),  # too few starts: formation fallback
    ]
    calibration = Calibration("outfield", 855, group, [], Cut(-0.01, (), 0.005))
    assert calibration.sizes() == (2, 3, 1)
    assert [p.player_id for p in calibration.nearest(2)] == [3, 4]
    assert [p.player_id for p in calibration.disagreements()] == [2, 4]


def test_no_cut_classifies_nobody() -> None:
    calibration = Calibration("outfield", 855, [line(1, -0.1)], [], None)
    assert calibration.sizes() == (0, 0, 1)
    assert calibration.nearest(5) == [] and calibration.disagreements() == []


# --- the report on the fixture season -------------------------------------------------------
#
# The fixture's 4-2-3-1 side has a left-back (depth 0.3125), a striker (0.84375) and a keeper.
# Re-labelled here as a DM (the left-back) and a CM (the striker), each side's outfield mean
# is 0.578125, so the "DM" sits at -0.265625 and the "CM" at +0.265625 in every match.


def fixture_midfield(engine: Engine) -> None:
    with Session(engine) as session, session.begin():

        def ids(*players: str) -> list[int]:
            return list(session.scalars(
                select(PlayerSourceId.player_id).where(PlayerSourceId.external_id.in_(players))
            ))  # fmt: skip

        for players, role in ((("p_ALB01", "p_CLB01"), "DM"), (("p_AST01", "p_CST01"), "CM")):
            session.execute(
                update(Appearance)
                .where(Appearance.player_id.in_(ids(*players)), Appearance.is_starter.is_(True))
                .values(role=role)
            )
        # The fixture reuses names per team; give some players their own, for anchor lookups.
        for player, name in (
            ("p_CLB01", "Cleo Deep"),
            ("p_CST01", "Cyd High"),
            ("p_BGK02", "Bo Keeper"),
            ("p_BGK03", "Hugo Bench"),
        ):
            session.execute(
                update(Player)
                .where(Player.id.in_(ids(player)))
                .values(name=name, search_name=name.lower())
            )
        aggregate_season(session, find_season(session, LEAGUE, SEASON).id)


@pytest.fixture
def fixture_anchors(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(depth, "MIN_DEPTH_STARTS", 1)  # the fixture has 1-2 starts each
    monkeypatch.setattr(
        depth,
        "ANCHORS",
        (("cleo deep", "DM"), ("cyd high", "CM"), ("bea fullback", "DM"),
         ("bo keeper", "DM"), ("nobody here", "CM")),
    )  # fmt: skip


def run(engine: Engine, reference: Any) -> Calibration:
    with Session(engine) as session:
        return calibrate(session, find_season(session, LEAGUE, SEASON).id, reference)


def test_calibration_on_the_fixture_season(synced_season: Engine, fixture_anchors: None) -> None:
    fixture_midfield(synced_season)
    result = run(synced_season, "outfield")
    assert len(result.group) == 4  # A's and C's left-back and striker, now central mids
    values = {p.name: p.depth.relative for p in result.group if p.depth}
    assert values["Cleo Deep"] == pytest.approx(-0.265625)
    assert values["Cyd High"] == pytest.approx(0.265625)
    assert [p.name for p in result.group][:2] == ["Bea Fullbäck", "Cleo Deep"]  # deepest first
    status = {a.query: a.status for a in result.anchors}
    assert status["cleo deep"] == status["cyd high"] == status["bea fullback"] == "ok"
    assert status["bo keeper"] == "in the GK group (mostly GK)"
    assert status["nobody here"] == "not found in this season"
    assert result.cut is not None
    assert result.cut.value == pytest.approx(0.0) and result.cut.wrong == ()
    assert result.sizes() == (2, 2, 0)
    cleo = next(p for p in result.group if p.name == "Cleo Deep")
    assert cleo.depth is not None and cleo.depth.deepest_share == 1.0  # deeper every time


def test_without_centre_backs_nobody_has_a_reference(
    synced_season: Engine, fixture_anchors: None
) -> None:
    fixture_midfield(synced_season)
    result = run(synced_season, "centre_backs")  # the fixture has no centre-backs
    assert result.cut is None and result.sizes() == (0, 0, 4)
    assert {a.status for a in result.anchors if a.query == "cleo deep"} == {
        "only 0 central-mid starts with a heatmap"
    }


def test_anchor_lookups(synced_season: Engine, monkeypatch: pytest.MonkeyPatch) -> None:
    fixture_midfield(synced_season)
    monkeypatch.setattr(depth, "ANCHORS", (("gus ten", "CM"), ("hugo bench", "DM")))
    status = {a.query: a.status for a in run(synced_season, "outfield").anchors}
    assert status["gus ten"] == "ambiguous (2 players match)"  # A's and B's
    assert status["hugo bench"] == "below the minimum (10 < 45 min)"  # two 5' cameos


def test_report_needs_aggregates(synced_season: Engine) -> None:
    with pytest.raises(DepthReportError, match="aggregate"):
        run(synced_season, "outfield")


def test_report_needs_heatmap_depths(synced_season: Engine) -> None:
    fixture_midfield(synced_season)
    with Session(synced_season) as session, session.begin():
        session.execute(update(Appearance).values(depth=None))
    with pytest.raises(DepthReportError, match="sync season"):
        run(synced_season, "outfield")
